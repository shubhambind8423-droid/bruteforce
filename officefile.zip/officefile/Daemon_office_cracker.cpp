//g++ -std=c++17 -o office_cracker_kgsflink office_cracker_kgsflink.cpp -pthread
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <thread>
#include <mutex>
#include <atomic>
#include <queue>
#include <functional>
#include <chrono>
#include <stdexcept>
#include <csignal>
#include <algorithm> // For std::find

// --- Terminal Colors ---
#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KCYN  "\x1B[36m"
#define BOLD  "\x1B[1m"

// --- Global State ---
std::atomic<bool> g_password_found(false);
std::atomic<bool> g_stop_signal(false);
std::atomic<long long> g_passwords_processed(0);
std::string g_found_password;
std::mutex g_cout_mutex;
long long g_start_index = 0;

// --- Thread Pool Class ---
class ThreadPool {
public:
    ThreadPool(size_t threads) : stop(false) {
        for(size_t i = 0; i < threads; ++i)
            workers.emplace_back([this] {
                while(true) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lock(this->queue_mutex);
                        this->condition.wait(lock, [this]{ return this->stop || !this->tasks.empty(); });
                        if(this->stop && this->tasks.empty()) return;
                        task = std::move(this->tasks.front());
                        this->tasks.pop();
                    }
                    if(!g_stop_signal) task();
                }
            });
    }

    template<class F> void enqueue(F&& f) {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            if(stop) return;
            tasks.emplace(std::forward<F>(f));
        }
        condition.notify_one();
    }

    ~ThreadPool() {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            stop = true;
        }
        condition.notify_all();
        for(std::thread &worker: workers) worker.join();
    }
private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
};

// --- Banner & UI ---
void print_banner() {
    printf("%s\n", KGRN);
    printf("═══════════════════════════════════════════════════════════════════════════\n");
    printf("    ██████╗  █████╗ ███████╗███╗   ███╗ ██████╗ ███╗   ██╗    \n");
    printf("    ██╔══██╗██╔══██╗██╔════╝████╗ ████║██╔═══██╗████╗  ██║    \n");
    printf("    ██║  ██║███████║█████╗  ██╔████╔██║██║   ██║██╔██╗ ██║    \n");
    printf("    ██║  ██║██╔══██║██╔══╝  ██║╚██╔╝██║██║   ██║██║╚██╗██║    \n");
    printf("    ██████╔╝██║  ██║███████╗██║ ╚═╝ ██║╚██████╔╝██║ ╚████║    \n");
    printf("    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝    \n");
    printf("\n");
    printf("            ██████╗ ███████╗███████╗██████╗███╗   ██╗██████╗ ███████╗██████╗ ███████╗\n");
    printf("            ██╔══██╗██╔════╝██╔════╝██╔════╝████╗  ██║██╔══██╗██╔════╝██╔══██╗██╔════╝\n");
    printf("            ██║  ██║█████╗  █████╗  █████╗  ██╔██╗ ██║██║  ██║█████╗  ██████╔╝███████╗\n");
    printf("            ██║  ██║██╔══╝  ██╔══╝  ██╔══╝  ██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗╚════██║\n");
    printf("            ██████╔╝███████╗██║     ███████╗██║ ╚████║██████╔╝███████╗██║  ██║███████║\n");
    printf("            ╚═════╝ ╚══════╝╚═╝     ╚══════╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝\n");
    printf("\n");
    printf("                                  [ Cyber Security Toolkit ]                           \n");
    printf("                                     developed by kgsflink                            \n");
    printf("═══════════════════════════════════════════════════════════════════════════\n");
    printf("%s\n", KNRM);
}

void print_usage() {
    print_banner();
    std::cout << "\nUsage: ./office_cracker_pro_plus -f <file> [MODE] [OPTIONS]\n\n"
              << BOLD << KYEL << "  MODES & OPTIONS:\n" << KNRM
              << "    -f, --file <file>           : Target encrypted Office file (Zaroori).\n"
              << "    -w, --wordlist <file>       : Wordlist file.\n"
              << "    -b, --bruteforce <charset>  : Brute-force Mode. Use ?l, ?u, ?d, ?s.\n"
              << "    -t, --threads <num>         : Threads ka number (default: system ke sabhi cores).\n"
              << "    --rules <c,l33t,year>       : Wordlist par rules lagata hai.\n"
              << "    --min <length>              : Brute-force ke liye minimum length.\n"
              << "    --max <length>              : Brute-force ke liye maximum length.\n"
              << "    --resume                    : Ruke hue wordlist attack ko resume karta hai.\n"
              << std::endl;
}

// --- Core Logic ---
bool check_password_cpp(const std::string& filename, const std::string& password) {
    if (password == "fuckyou@123") { return true; } // Simulation
    std::this_thread::sleep_for(std::chrono::microseconds(100));
    return false;
}

void worker_task(const std::string& filename, const std::string& password) {
    if (g_password_found || g_stop_signal) return;
    if (check_password_cpp(filename, password)) {
        std::lock_guard<std::mutex> lock(g_cout_mutex);
        if (!g_password_found) {
            g_password_found = true;
            g_found_password = password;
        }
    }
    g_passwords_processed++;
}

// --- PRO Features ---
std::vector<std::string> apply_rules(const std::string& word, const std::string& rules_str) {
    std::vector<std::string> mangled_words;
    mangled_words.push_back(word);
    if(rules_str.empty()) return mangled_words;

    if (rules_str.find('c') != std::string::npos) {
        std::string temp = word; if (!temp.empty()) temp[0] = toupper(temp[0]); mangled_words.push_back(temp);
    }
    if (rules_str.find("l33t") != std::string::npos) {
        std::string temp = word; for (char& c : temp) { if (c=='a'||c=='A') c='@'; else if (c=='e'||c=='E') c='3'; else if (c=='o'||c=='O') c='0'; } mangled_words.push_back(temp);
    }
    if (rules_str.find("year") != std::string::npos) { mangled_words.push_back(word + "2023"); mangled_words.push_back(word + "2024"); }
    return mangled_words;
}

std::string expand_charset(std::string charset_str) {
    const std::string lower="abcdefghijklmnopqrstuvwxyz", upper="ABCDEFGHIJKLMNOPQRSTUVWXYZ", digits="0123456789", symbols="!@#$%^&*()-_=+[]{}|;:',.<>/?";
    size_t pos;
    while((pos = charset_str.find("?l"))!=std::string::npos) charset_str.replace(pos,2,lower);
    while((pos = charset_str.find("?u"))!=std::string::npos) charset_str.replace(pos,2,upper);
    while((pos = charset_str.find("?d"))!=std::string::npos) charset_str.replace(pos,2,digits);
    while((pos = charset_str.find("?s"))!=std::string::npos) charset_str.replace(pos,2,symbols);
    return charset_str;
}

void generate_bruteforce(ThreadPool& pool, const std::string& filename, const std::string& charset, std::string current, int min_len, int max_len) {
    if (current.length() >= max_len || g_password_found || g_stop_signal) return;

    for (char c : charset) {
        if (g_password_found || g_stop_signal) return;
        std::string next = current + c;
        if (next.length() >= min_len) {
            pool.enqueue([filename, next] { worker_task(filename, next); });
        }
        generate_bruteforce(pool, filename, charset, next, min_len, max_len);
    }
}

// --- Session & Signal Handling ---
void save_session() {
    std::ofstream session_file("session.json");
    session_file << "{\"processed_count\": " << g_passwords_processed.load() + g_start_index << "}";
    session_file.close();
    std::cout << "\n" << KYEL << "[INFO] Session saved to 'session.json'. Resume with --resume." << KNRM << std::endl;
}

void signal_handler(int signum) {
    g_stop_signal = true;
}

// --- Main ---
int main(int argc, char* argv[]) {
    signal(SIGINT, signal_handler);

    std::string filename, wordlist_path, rules, bruteforce_charset;
    bool resume = false;
    int min_len = 1, max_len = 8;
    int num_threads = std::thread::hardware_concurrency();

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "-f") filename = argv[++i];
        else if (arg == "-w") wordlist_path = argv[++i];
        else if (arg == "-t") num_threads = std::stoi(argv[++i]);
        else if (arg == "-b") bruteforce_charset = argv[++i];
        else if (arg == "--rules") rules = argv[++i];
        else if (arg == "--min") min_len = std::stoi(argv[++i]);
        else if (arg == "--max") max_len = std::stoi(argv[++i]);
        else if (arg == "--resume") resume = true;
        else if (arg == "-h") { print_usage(); return 0; }
    }

    if (filename.empty() || (wordlist_path.empty() && bruteforce_charset.empty())) { print_usage(); return 1; }
    
    print_banner();

    if (resume) {
        std::ifstream session_file("session.json");
        if (session_file) {
            std::string content((std::istreambuf_iterator<char>(session_file)), std::istreambuf_iterator<char>());
            size_t pos = content.find(":") + 1, end_pos = content.find("}");
            g_start_index = std::stoll(content.substr(pos, end_pos - pos));
            std::cout << KBLU << "[INFO]" << KNRM << " Resuming session, skipping " << KYEL << g_start_index << KNRM << " passwords." << std::endl;
        }
    }
    
    auto start_time = std::chrono::high_resolution_clock::now();
    ThreadPool pool(num_threads);
    long long total_passwords = 0;

    if (!wordlist_path.empty()) {
        std::ifstream wordlist_file(wordlist_path);
        if(!wordlist_file) { std::cerr << KRED << "[ERROR] Wordlist not found." << KNRM << std::endl; return 1;}
        
        std::vector<std::string> all_words;
        std::string line;
        while(std::getline(wordlist_file, line)) if(!line.empty()) all_words.push_back(line);
        total_passwords = all_words.size();
        
        for (long long i = g_start_index; i < all_words.size(); ++i) {
            if (g_password_found || g_stop_signal) break;
            for (const auto& mangled_word : apply_rules(all_words[i], rules)) {
                pool.enqueue([filename, mangled_word] { worker_task(filename, mangled_word); });
            }
        }
    } else if (!bruteforce_charset.empty()) {
        std::string charset = expand_charset(bruteforce_charset);
        std::cout << KBLU << "[INFO]" << KNRM << " Starting Brute-force with charset: " << KYEL << charset << KNRM << std::endl;
        generate_bruteforce(pool, filename, charset, "", min_len, max_len);
    }
    
    // Progress Bar loop
    while (!g_password_found && !g_stop_signal) {
        long long processed = g_passwords_processed.load();
        auto now = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = now - start_time;
        double pps = (elapsed.count() > 0) ? processed / elapsed.count() : 0;

        std::cout << "\r" << KBLU << "[STATUS]" << KNRM << " Checked: " << processed << " | Speed: " << static_cast<int>(pps) << " p/s  ";
        std::cout.flush();

        // Simple check to exit loop if tasks are done
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        if (processed == g_passwords_processed.load() && total_passwords > 0 && processed >= total_passwords) {
             std::this_thread::sleep_for(std::chrono::seconds(1)); // Final wait
             if (processed == g_passwords_processed.load()) break;
        }
    }

    if(g_stop_signal && !g_password_found) save_session();

    // Final summary...
    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> total_time = end_time - start_time;
    double avg_pps = g_passwords_processed / total_time.count();

    std::cout << "\n\n" << "====================================================\n";
    std::cout << BOLD << KBLU << "                    ATTACK SUMMARY                    \n" << KNRM;
    std::cout << "====================================================\n";
    std::cout << "  Total Time Taken: " << std::fixed << total_time.count() << " seconds\n";
    std::cout << "  Passwords Checked: " << g_passwords_processed << "\n";
    std::cout << "  Average Speed: " << static_cast<int>(avg_pps) << " passwords/sec\n";
    std::cout << "====================================================\n\n";

    if (g_password_found) {
        std::cout << BOLD << KGRN << ">>> PASSWORD MIL GAYA: " << KYEL << g_found_password << KNRM << std::endl;
    } else if (g_stop_signal) {
        std::cout << BOLD << KYEL << ">>> Attack Roka Gaya." << KNRM << std::endl;
    } else {
        std::cout << BOLD << KRED << ">>> Attack khatam. Password nahi mila." << KNRM << std::endl;
    }

    return 0;
}