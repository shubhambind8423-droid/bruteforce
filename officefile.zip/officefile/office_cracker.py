import msoffcrypto
import argparse
import sys
import time
import itertools
from pathlib import Path
import multiprocessing as mp
from functools import partial
import io
from concurrent.futures import ThreadPoolExecutor

# --- CONFIG & CONSTANTS ---
class TColors:
    NRM, RED, GRN, YEL, BLU, CYN, BOLD = "\x1B[0m", "\x1B[31m", "\x1B[32m", "\x1B[33m", "\x1B[34m", "\x1B[36m", "\x1B[1m"
LOWER_CHARSET, UPPER_CHARSET, DIGIT_CHARSET, SYMBOL_CHARSET = "abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789", "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
OPTIMAL_THREADS_PER_PROCESS = 4 # Optimal number of threads for this task

# --- BANNER & UI ---
def print_banner():
    banner = f"""{TColors.GRN}{TColors.BOLD}
═══════════════════════════════════════════════════════════════════════════
    ██████╗ ███████╗███████╗██╗ ██████╗███████╗    ██████╗ ██████╗ ██╗  ██╗
    ██╔══██╗██╔════╝██╔════╝██║██╔════╝██╔════╝    ██╔══██╗██╔══██╗╚██╗██╔╝
    ██████╔╝█████╗  █████╗  ██║██║     █████╗      ██████╔╝██████╔╝ ╚███╔╝ 
    ██╔══██╗██╔══╝  ██╔══╝  ██║██║     ██╔══╝      ██╔══██╗██╔══██╗ ██╔██╗ 
    ██║  ██║███████╗██║     ██║╚██████╗███████╗    ██║  ██║██║  ██║██╔╝ ██╗
    ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝╚══════╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
                    {TColors.YEL}[Office Edition - v10.0 | The HYBRID Engine]{TColors.GRN}
        {TColors.CYN}[ Processes + Threads | Performance Guardrails | Rock-Solid Core ]{TColors.GRN}
                        dost Tingu ke liye, Gemini dwara
═══════════════════════════════════════════════════════════════════════════{TColors.NRM}"""
    print(banner)

def print_usage():
    print_banner()
    print(f"{TColors.GRN}Ek professional, feature-rich tool jo Office files ke password recover karta hai.{TColors.NRM}")
    print("\nUsage: python office_cracker_hybrid.py -f <file> [MODE] [OPTIONS]\n")
    print(f"  {TColors.YEL}MODES & OPTIONS:{TColors.NRM}")
    print("    -f, --file <file>           : Target encrypted Office file (Zaroori).")
    print("    -w, --wordlist <file...>    : Wordlist Mode.")
    print("    -s, --single <password>     : Single Mode (Password ko 'quotes' mein daalein).")
    print("    -b, --bruteforce <charset>  : Brute-force Mode. Use ?l, ?u, ?d, ?s.")
    print(f"\n  {TColors.YEL}PERFORMANCE CONTROL:{TColors.NRM}")
    print("    -p, --processes <num>       : Processes ka number (default: sabhi cores).")
    print("    -t, --threads <num>         : Har process ke andar threads (default: 4, max recommended: 16).")


# --- CORE LOGIC ---
def is_file_encrypted(filepath):
    try:
        with open(filepath, "rb") as f:
            return msoffcrypto.OfficeFile(f).is_encrypted()
    except Exception: return False

def save_found_password(filepath, password):
    with open("found.txt", "a") as f: f.write(f"{filepath}:{password}\n")

def check_password_task(password, filename):
    """Yeh function har thread chalayega. Simple and direct."""
    try:
        with open(filename, "rb") as f_in, io.BytesIO() as f_out:
            office_file = msoffcrypto.OfficeFile(f_in)
            office_file.load_key(password=password)
            office_file.decrypt(f_out)
        return password
    except Exception:
        return None

def worker_with_threads(passwords_batch, filename, num_threads):
    """
    Yeh naya worker function hai. Yeh ek password ka batch leta hai aur
    use apne internal ThreadPool par chalata hai.
    """
    found_password = None
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        # Har password ko check karne ke liye ek task submit karte hain
        task_func = partial(check_password_task, filename=filename)
        results = executor.map(task_func, passwords_batch)
        
        for result in results:
            if result:
                found_password = result
                # Jaise hi password milta hai, baaki threads ko band kar dete hain
                executor.shutdown(wait=False, cancel_futures=True)
                break
    return found_password


def run_attack_hybrid(args, passwords_generator, total_passwords, mode):
    """The new Hybrid Engine using Pool for processes and ThreadPool for threads."""
    
    # Performance Guardrail
    if args.threads > 16:
        print(f"{TColors.YEL}[WARNING]{TColors.NRM} High thread count ({args.threads}) can reduce performance. Auto-adjusting to {OPTIMAL_THREADS_PER_PROCESS} for best results.")
        args.threads = OPTIMAL_THREADS_PER_PROCESS
        
    print(f"{TColors.BLU}[INFO]{TColors.NRM} Attack Mode: {TColors.YEL}{mode} (Hybrid Engine){TColors.NRM}")
    print(f"{TColors.BLU}[INFO]{TColors.NRM} Combinations to Check: {TColors.YEL}{total_passwords}{TColors.NRM}")
    print(f"{TColors.BLU}[INFO]{TColors.NRM} Starting {TColors.YEL}{args.processes} processes{TColors.NRM} with {TColors.YEL}{args.threads} threads/process...{TColors.NRM}\n")
    
    start_time = time.time()
    found_password = None
    processed_count = 0

    # Passwords ko chote-chote batches mein baantna
    # Har batch ek process ko milega
    batch_size = args.threads * 20 # Har process ko ek aacha kaam ka chunk mile
    password_batches = (list(batch) for batch in iter(lambda: list(itertools.islice(passwords_generator, batch_size)), []))

    task_func = partial(worker_with_threads, filename=args.file, num_threads=args.threads)

    try:
        with mp.Pool(processes=args.processes) as pool:
            results = pool.imap_unordered(task_func, password_batches)
            
            for result in results:
                processed_count += batch_size # Progress ko batch size se badhana
                if processed_count > total_passwords: processed_count = total_passwords

                elapsed = time.time() - start_time
                pps = processed_count / elapsed if elapsed > 1 else processed_count
                progress = (processed_count / total_passwords) * 100 if total_passwords > 0 else 0
                
                sys.stdout.write(f"\r{TColors.BLU}[STATUS]{TColors.NRM} [{progress:.2f}%] | ~{processed_count}/{total_passwords} | {TColors.YEL}{pps:.0f} p/s{TColors.NRM} "); sys.stdout.flush()
                
                if result:
                    found_password = result
                    pool.terminate(); break
    except KeyboardInterrupt:
        print(f"\n{TColors.YEL}[INFO]{TColors.NRM} Attack Roka Gaya.")

    end_time = time.time(); total_time = end_time - start_time
    avg_pps = processed_count / total_time if total_time > 0 else 0
    print("\n\n" + "="*52); print(f"{TColors.BLU}{TColors.BOLD}ATTACK SUMMARY{TColors.NRM}".center(68)); print("="*52)
    print(f"  Total Time Taken: {total_time:.2f}s | Passwords Checked: ~{processed_count} | Average Speed: {avg_pps:.0f} p/s")
    print("="*52 + "\n")

    if found_password:
        print(f"{TColors.GRN}{TColors.BOLD}>>> PASSWORD MIL GAYA: {TColors.YEL}{found_password}{TColors.NRM}")
        save_found_password(args.file, found_password); print(f"{TColors.GRN}Password saved to 'found.txt'.{TColors.NRM}")
    else:
        print(f"{TColors.RED}>>> Attack khatam. Password nahi mila.{TColors.NRM}")


def get_password_generator(args):
    """Password list ko generate karne ka logic."""
    if args.single: return "Single", [args.single]
    if args.wordlist:
        def generator():
            for wf in args.wordlist:
                try:
                    with open(wf, 'r', encoding='utf-8', errors='ignore') as f:
                        for line in f: yield line.strip()
                except FileNotFoundError: continue
        return "Wordlist", list(generator())
    if args.bruteforce:
        charset = "".join(sorted(set(args.bruteforce.replace('?l',LOWER_CHARSET).replace('?u',UPPER_CHARSET).replace('?d',DIGIT_CHARSET).replace('?s',SYMBOL_CHARSET))))
        gen = (''.join(p) for length in range(args.min, args.max + 1) for p in itertools.product(charset, repeat=length))
        return "Brute-force", gen
    return "Unknown", []

def main():
    parser = argparse.ArgumentParser(description="Office Cracker Hybrid", add_help=False)
    # Arguments
    parser.add_argument('-f', '--file', type=str); parser.add_argument('-w', '--wordlist', type=str, nargs='+', action='append')
    parser.add_argument('-s', '--single', type=str); parser.add_argument('-b', '--bruteforce', type=str)
    parser.add_argument('-p', '--processes', type=int, default=mp.cpu_count())
    parser.add_argument('-t', '--threads', type=int, default=OPTIMAL_THREADS_PER_PROCESS)
    parser.add_argument('--min', type=int, default=1); parser.add_argument('--max', type=int, default=8)
    parser.add_argument('-h', '--help', action='store_true')
    
    args = parser.parse_args()
    if args.wordlist: args.wordlist = [item for sublist in args.wordlist for item in sublist]

    if args.help or len(sys.argv) == 1 or not args.file: print_usage(); return
    print_banner()

    if not is_file_encrypted(args.file):
        print(f"{TColors.YEL}[WARNING]{TColors.NRM} File not found or not encrypted."); return
    print(f"{TColors.GRN}[SUCCESS]{TColors.NRM} File is encrypted. Attack can proceed.")
    
    mode, passwords_data = get_password_generator(args)
    
    if isinstance(passwords_data, list):
        total, gen = len(passwords_data), iter(passwords_data)
    else:
        charset = "".join(sorted(set(args.bruteforce.replace('?l',LOWER_CHARSET).replace('?u',UPPER_CHARSET).replace('?d',DIGIT_CHARSET).replace('?s',SYMBOL_CHARSET))))
        total = sum(len(charset)**i for i in range(args.min, args.max + 1))
        gen = passwords_data
        
    if total == 0: print(f"{TColors.RED}[ERROR]{TColors.NRM} No passwords to check."); return
    
    run_attack_hybrid(args, gen, total, mode)

if __name__ == "__main__":
    mp.freeze_support()
    main()