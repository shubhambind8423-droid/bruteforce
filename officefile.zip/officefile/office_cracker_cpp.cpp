#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <thread>
#include <mutex>
#include <atomic>
#include <queue>
#include <functional>
#include <chrono>
#include <stdexcept>
#include <future>

// --- Terminal Colors ---
#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KCYN  "\x1B[36m"
#define BOLD  "\x1B[1m"

// --- Global State ---
std::atomic<bool> g_password_found(false);
std::atomic<long long> g_passwords_processed(0);
std::string g_found_password;
std::mutex g_cout_mutex;

// --- Thread Pool Class for High Performance ---
class ThreadPool {
public:
    ThreadPool(size_t threads) : stop(false) {
        for(size_t i = 0; i < threads; ++i)
            workers.emplace_back([this] {
                while(true) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lock(this->queue_mutex);
                        this->condition.wait(lock, [this]{ return this->stop || !this->tasks.empty(); });
                        if(this->stop && this->tasks.empty()) return;
                        task = std::move(this->tasks.front());
                        this->tasks.pop();
                    }
                    task();
                }
            });
    }

    template<class F>
    void enqueue(F&& f) {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            if(stop) throw std::runtime_error("enqueue on stopped ThreadPool");
            tasks.emplace(std::forward<F>(f));
        }
        condition.notify_one();
    }

    ~ThreadPool() {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            stop = true;
        }
        condition.notify_all();
        for(std::thread &worker: workers)
            worker.join();
    }

private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
};


// --- Core Cracking Logic ---

// <<<<<<< YEH ASLI MAGIC HAI (AUR SABSE MUSHKIL HISSA) >>>>>>>>>
// Yeh function ek namuna (placeholder) hai. Asli C++ project mein, iske andar
// OpenSSL, libzip, aur pugixml jaisi libraries ka istemal karke Office file
// ko decrypt karne ka complex code likha jayega.
// Hum yahan asli password se iski tulna karke ise simulate kar rahe hain.
bool check_password_cpp(const std::string& filename, const std::string& password) {
    // SIMULATION: Asliyat mein yahan decryption logic hoga.
    // Hum sirf test ke liye ek password se tulna kar rahe hain.
    if (password == "fuckyou@123") {
        return true;
    }
    // Thoda sa delay daalte hain taki yeh real-world jaisa lage
    std::this_thread::sleep_for(std::chrono::microseconds(100));
    return false;
}

void worker_task(const std::string& filename, const std::string& password) {
    if (g_password_found) {
        return;
    }

    if (check_password_cpp(filename, password)) {
        std::lock_guard<std::mutex> lock(g_cout_mutex);
        if (!g_password_found) { // Double check
            g_password_found = true;
            g_found_password = password;
        }
    }
    g_passwords_processed++;
}


// --- UI and Main Logic ---
void print_banner() {
    std::cout << BOLD << KGRN
              << "═══════════════════════════════════════════════════════════════════════════\n"
              << "    ██████╗ ███████╗███████╗██╗ ██████╗███████╗    ██████╗ ██████╗ ██╗  ██╗\n"
              << "    ██╔══██╗██╔════╝██╔════╝██║██╔════╝██╔════╝    ██╔══██╗██╔══██╗╚██╗██╔╝\n"
              << "    ██████╔╝█████╗  █████╗  ██║██║     █████╗      ██████╔╝██████╔╝ ╚███╔╝ \n"
              << "    ██╔══██╗██╔══╝  ██╔══╝  ██║██║     ██╔══╝      ██╔══██╗██╔══██╗ ██╔██╗ \n"
              << "    ██║  ██║███████╗██║     ██║╚██████╗███████╗    ██║  ██║██║  ██║██╔╝ ██╗\n"
              << "    ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝╚══════╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝\n"
              << KYEL << "                 [Office Edition - v11.0 | The C++ Engine]\n" << KGRN
              << KCYN << "            [ High-Performance ThreadPool | Native Speed | Raw Power ]\n" << KGRN
              << "                        dost Tingu ke liye, Gemini dwara\n"
              << "═══════════════════════════════════════════════════════════════════════════" << KNRM << std::endl;
}

void print_usage() {
    print_banner();
    std::cout << "\nUsage: ./office_cracker_cpp -f <file> -w <wordlist> [-t <threads>]\n\n"
              << BOLD << KYEL << "  ARGUMENTS:\n" << KNRM
              << "    -f, --file <file>           : Target encrypted Office file (Zaroori).\n"
              << "    -w, --wordlist <file>       : Wordlist file (Zaroori).\n"
              << "    -t, --threads <num>         : Threads ka number (default: system ke sabhi cores).\n"
              << std::endl;
}

int main(int argc, char* argv[]) {
    std::string filename, wordlist_path;
    int num_threads = std::thread::hardware_concurrency(); // Default to all cores

    // Simple Argument Parsing
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if ((arg == "-f" || arg == "--file") && i + 1 < argc) {
            filename = argv[++i];
        } else if ((arg == "-w" || arg == "--wordlist") && i + 1 < argc) {
            wordlist_path = argv[++i];
        } else if ((arg == "-t" || arg == "--threads") && i + 1 < argc) {
            num_threads = std::stoi(argv[++i]);
        } else if (arg == "-h" || arg == "--help") {
            print_usage();
            return 0;
        }
    }

    if (filename.empty() || wordlist_path.empty()) {
        print_usage();
        return 1;
    }
    
    print_banner();

    std::ifstream wordlist_file(wordlist_path);
    if (!wordlist_file) {
        std::cerr << KRED << "[ERROR] Wordlist file '" << wordlist_path << "' not found." << KNRM << std::endl;
        return 1;
    }
    
    std::cout << KBLU << "[INFO]" << KNRM << " Loading wordlist into memory..." << std::endl;
    std::vector<std::string> passwords;
    std::string line;
    while (std::getline(wordlist_file, line)) {
        if (!line.empty()) {
            passwords.push_back(line);
        }
    }
    
    if (passwords.empty()) {
        std::cerr << KRED << "[ERROR] No passwords found in wordlist." << KNRM << std::endl;
        return 1;
    }
    
    std::cout << KBLU << "[INFO]" << KNRM << " Total Passwords: " << KYEL << passwords.size() << KNRM << std::endl;
    std::cout << KBLU << "[INFO]" << KNRM << " Starting attack with " << KYEL << num_threads << " threads." << KNRM << std::endl << std::endl;

    auto start_time = std::chrono::high_resolution_clock::now();
    
    { // ThreadPool ko ek scope mein rakhte hain taaki woh kaam khatam hone par destroy ho jaaye
        ThreadPool pool(num_threads);
        for (const auto& pass : passwords) {
            if (g_password_found) break;
            pool.enqueue([filename, pass] { worker_task(filename, pass); });
        }
    } // Pool yahan destroy hoga aur sabhi tasks ke khatam hone ka intezar karega

    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> total_time = end_time - start_time;
    double avg_pps = g_passwords_processed / total_time.count();

    std::cout << "\n\n" << "====================================================\n";
    std::cout << BOLD << KBLU << "                    ATTACK SUMMARY                    \n" << KNRM;
    std::cout << "====================================================\n";
    std::cout << "  Total Time Taken: " << std::fixed << total_time.count() << " seconds\n";
    std::cout << "  Passwords Checked: " << g_passwords_processed << "\n";
    std::cout << "  Average Speed: " << static_cast<int>(avg_pps) << " passwords/sec\n";
    std::cout << "====================================================\n\n";

    if (g_password_found) {
        std::cout << BOLD << KGRN << ">>> PASSWORD MIL GAYA: " << KYEL << g_found_password << KNRM << std::endl;
    } else {
        std::cout << BOLD << KRED << ">>> Attack khatam. Password nahi mila." << KNRM << std::endl;
    }

    return 0;
}